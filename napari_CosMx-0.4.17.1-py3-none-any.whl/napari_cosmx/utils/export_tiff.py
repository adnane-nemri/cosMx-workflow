#!/usr/bin/env python

import numpy as np
from tifffile import TiffWriter, imread
import zarr
import dask.array as da
import argparse
import os
import sys
from scipy import ndimage
from tqdm import tqdm
from skimage.transform import resize
from pathlib import Path
from dask.diagnostics import ProgressBar
import tempfile
from napari_cosmx.pairing import pair
import pandas as pd
import re

def main():
    parser = argparse.ArgumentParser(description='Export stitched Zarr to OME-TIFF')
    parser.add_argument("-i", "--inputdir",
        help="Required: Path to existing stitched output.",
        default=".")
    parser.add_argument("-o", "--outputdir",
        help="Required: Path to write OME-TIFF file.",
        default=".")
    parser.add_argument("--filename",
        help="Name for OME-TIFF file, use ome.tif extension.",
        default="cosmx-wsi.ome.tif")
    parser.add_argument("--compression",
        help="Passed to TiffWriter, default is 'zlib'. "+
        "Other options include 'lzma' (smallest), 'lzw', and 'none'",
        default='zlib')
    parser.add_argument("--segmentation",
        help="\nOptional: Create TIFF for segmentation mask.",
        action='store_true')
    parser.add_argument("--libvips",
        help="\nOptional: Use libvips to create pyramidal image, will be slower but more memory-efficient.",
        action='store_true')
    parser.add_argument("--channels",
        help="Optional: Output only specific morphology channels",
        nargs="*",
        default=None)
    parser.add_argument("--metadata",
        help="Optional: Path to csv file with first column cell_ID,\
            second column metadata values.",
        default=None)
    parser.add_argument("--proteins",
        help="Optional: Output only specific proteins",
        nargs="*",
        default=None)
    parser.add_argument("-u", "--umperpx",
        help="Optional: Override image scale in um per pixel.\n"+
        "Instrument-specific values to use:\n-> beta04 = 0.1228",
        default=None,
        type=float)
    parser.add_argument("--levels",
        help="Optional: Specify number of pyramid levels.\n",
        default=8,
        type=int)
    parser.add_argument("--vipshome",
        help="Optional: Path to vips binaries. Required in Windows if vips and associated DLLs are not in PATH",
        default=None)
    parser.add_argument("--vipsconcurrency",
        help="Optional: Specify number of threads for vips.\n",
        default=8,
        type=int)
    args = parser.parse_args()

    # Check output directory
    if not os.path.exists(args.outputdir):
        print(f"Output path does not exist, creating {args.outputdir}")
        os.mkdir(args.outputdir)
    store = os.path.join(args.inputdir, "images")
    if not os.path.exists(store):
        sys.exit(f"Could not find images directory at {args.inputdir}")

    grp = zarr.open(store, mode='r')
    channels = []
    
    if args.segmentation or args.metadata:
        channels = ["labels"]
    if args.proteins:
        if 'all' in [x.lower() for x in args.proteins]:
            proteins = ['protein/' + x for x in grp['protein'].group_keys()]
        else:
            invalid = [x for x in args.proteins if x not in grp['protein'].group_keys()]
            if invalid:
                sys.exit(f"Could not find proteins {invalid} in protein folder.")
            proteins = ['protein/' + x for x in args.proteins]
        channels.extend(proteins)
    if args.channels and args.channels != ['all']:
        channels.extend(args.channels)
        invalid = [x for x in args.channels if x not in grp.group_keys()]
        if invalid:
            sys.exit(f"Could not find channels {invalid} in images folder.")
    if args.channels == ['all'] or channels == []:
        channels[:0] = sorted(set(
            grp.group_keys()) - set(['labels', 'protein', 'composite', 'targets', 'fovgrid']))

    channel_names = [x.replace(".zarr", "").replace("protein/", "") for x in channels]
    metadata = grp[channels[0]].attrs
    datasets = metadata["multiscales"][0]["datasets"]

    if args.segmentation:
        def _edges(x):
            kernel = np.ones((3,3))
            kernel[1, 1] = -8
            arr = ndimage.convolve(x, kernel, output=np.uint16)
            arr[arr != 0] = 1
            return arr.astype('uint8')

        levels = [da.stack([da.from_zarr(
            store + f"/{i}", component=d["path"]).map_blocks(_edges)
            for i in channels])
            for d in datasets]
    elif args.metadata:
        df = pd.read_csv(args.metadata)
        cat = sorted(pd.unique(df.iloc[:, 1]))
        d = {df.columns[1]: cat, 'label': range(1, len(cat)+1)}
        fn = df.columns[1] + "_key.csv"
        path = os.path.join(args.outputdir, fn)
        pd.DataFrame(data=d).to_csv(path, index=False)
        # add UID
        res = [re.search("c_.*_(.*)_(.*)", i) for i in df.cell_ID]
        df['UID'] = [pair(int(i.group(1)), int(i.group(2))) for i in res]
        df.set_index('UID', inplace=True)
        vals = {i:cat.index(df.loc[i].iloc[1])+1 for i in df.index}
        def _map_labels_to_vals(arr):
            u, inv = np.unique(arr, return_inverse=True)
            res = np.array(
                [
                    vals[x]
                    if x in vals
                    else 0
                    for x in u
                ]
            )[inv].reshape(arr.shape)
            return res.astype('uint8')
        levels = [da.stack([da.from_zarr(
            store + f"/{i}", component=d["path"]).map_blocks(_map_labels_to_vals)
            for i in channels])
            for d in datasets]
    else:
        levels = [da.stack([da.from_zarr(
            store + f"/{i}", component=d["path"]) 
            for i in channels])
            for d in datasets]
    
    if 'scale_um' in grp.attrs['CosMx']:
        pixelsize = grp.attrs['CosMx']['scale_um']
    elif args.umperpx is not None:
        pixelsize = args.umperpx
    else:
        sys.exit("No um_per_px in metadata or provided as argument")

    pyramid_levels = len(datasets)
    if args.levels is not None:
        pyramid_levels = args.levels
    
    metadata={
        'axes': 'CYX',
        'Channel': {'Name': channel_names},
        'PhysicalSizeX': pixelsize,
        'PhysicalSizeXUnit': 'µm',
        'PhysicalSizeY': pixelsize,
        'PhysicalSizeYUnit': 'µm'
    }
    data = levels[0]
    resolution = tuple(datasets[0]['coordinateTransformations'][0]['scale'])
    path = os.path.join(args.outputdir, args.filename)
    
    if not args.libvips:
        with TiffWriter(path, bigtiff=True, ome=True) as tif:
            print(f"Writing pyramid levels for {channel_names}.")
            options = dict(
                resolutionunit='MICROMETER',
                tile=(1024, 1024),
                metadata=metadata,
                subifds=pyramid_levels - 1,
                compression=args.compression
            )
            for i in tqdm(range(pyramid_levels), ncols=60, smoothing=1):
                tif.write(
                    data=data,
                    resolution=resolution,
                    **options
                )
                if i == 0:
                    del options['metadata']
                    del options['subifds']
                if i < len(datasets) - 1:
                    data = levels[i + 1]
                    resolution = tuple(datasets[i + 1]['coordinateTransformations'][0]['scale'])
                else:
                    data = resize(
                        data,
                        output_shape=(data.shape[0], data.shape[1] // 2, data.shape[2] // 2),
                        order=0,
                        preserve_range=True,
                        anti_aliasing=False
                    )
                    resolution = tuple(2*i for i in resolution)    
    else:
        if os.name == "nt" and args.vipshome is not None:
            os.environ['PATH'] = args.vipshome + ';' + os.environ['PATH']
        os.environ['VIPS_PROGRESS'] = "1"
        os.environ['VIPS_CONCURRENCY'] = str(args.vipsconcurrency)

        # must import after updating path
        import pyvips
        tmpdirname = tempfile.mkdtemp(dir=args.outputdir)
        tmptif = os.path.join(tmpdirname, 'tmp.ome.tif')
        with TiffWriter(tmptif, bigtiff=True, ome=True) as tif:
            print(f"Writing uncompressed empty tiff for {channel_names}, shape: {data.shape}."+ 
            "\nThis could take a while.")
            options = dict(
                resolutionunit='MICROMETER',
                tile=(1024, 1024),
                metadata=metadata,
                compression=None,
            )
            tif.write(
                data=None,
                dtype=data.dtype,
                shape=data.shape,
                resolution=resolution,
                **options
            )
        # Open TIFF as Zarr
        store = imread(tmptif, mode='r+', aszarr=True)
        z = zarr.open(store, mode='r+')
        print(f"Writing data to tiff as zarr")
        with ProgressBar():
            da.to_zarr(arr=data, url=z)
        store.close()

        print(f"Creating pyramidal OME-TIFF at {path}")
        image = pyvips.Image.new_from_file(
            tmptif,
            n = len(channels)
        )
        tile_height = data.shape[1] // 2**(pyramid_levels - 1)
        tile_width = data.shape[2] // 2**(pyramid_levels - 1)
        tile_height = tile_height + 16 - (tile_height % 16)
        tile_width = tile_width + 16 - (tile_width % 16)
        image.tiffsave(
            path,
            compression="deflate", bigtiff=True, 
            tile=True, tile_width=tile_width, tile_height=tile_height,
            pyramid=True, subifd=True
        )

if __name__ == '__main__':
    sys.exit(main())