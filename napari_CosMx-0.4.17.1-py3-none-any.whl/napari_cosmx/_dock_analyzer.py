"""
Definition of custom QWidget to provide interface for Gemini module.
"""
from qtpy.QtCore import Qt, QSize, QItemSelectionModel
from qtpy.QtWidgets import (
    QCheckBox,
    QWidget,
    QGridLayout,
    QPushButton,
    QLabel,
    QComboBox,
    QGroupBox,
    QVBoxLayout,
    QListWidget,
    QListWidgetItem,
    QAbstractItemView,
    QLineEdit,
    QFileDialog,
    QHBoxLayout,
    QLineEdit
)

from qtpy.QtGui import (
    QIcon,
    QPixmap,
    QColor,
    QImage
)

from napari.utils.notifications import (
    notification_manager,
    show_info,
)
from napari.experimental import link_layers
from napari.layers import Labels, Image
from napari.utils.colormaps import AVAILABLE_COLORMAPS, label_colormap
from napari.utils.colormaps.vendored import colors as color_utils
import numpy as np
import pandas as pd
from os import path, listdir, system, sep, name
import os
from sysconfig import get_path
from ntpath import sep
import subprocess

class GeminiQWidgetAnalyzer(QWidget):
    def __init__(self, napari_viewer, gem):
        super().__init__()
        self.viewer = napari_viewer
        self.gem = gem


'''
    def show_analyzer(self):
        if self.viewer is not None:
            print("XXXXXXXXXXXXXXXXXXXXX")
            widgets = [w for w in self.viewer.window._dock_analyzer.values()
                if isinstance(w.widget(), GeminiQWidgetAnalyzer)]
            if len(widgets) != 0:
                for w in widgets: 
                    w.show()
            else: 
                self.viewer.window.add_dock_widget(GeminiQWidgetAnalyzer(self.viewer, self),
                    area ='right',
                    name = self.name)
'''